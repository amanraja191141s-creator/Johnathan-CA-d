# v98.63.9.22 — Tools and Scientific UI repair

## Recording-driven findings
- The 2026-11-21 recording showed tool labels wrapping vertically/character-by-character, card text too narrow, inconsistent card proportions, and scientific function labels too compressed.

## Fixes
- Reasserted the 3-column Tools grid with min-width-safe cards.
- Forced tool labels to horizontal writing, normal word breaking, no hyphenation, and a two-line clamp.
- Stabilized icon sizing, card padding, card heights, focus indication, and small-screen spacing.
- Rebuilt scientific function bank as a consistent 4×4 matrix with 42px minimum touch targets.
- Improved scientific display hierarchy, toolbar proportions, memory row, numeric keypad sizing, and secondary-function panel.
- Preserved existing scientific insertion tokens, inverse modifier logic, angle mode, memory controls, and tool destination IDs.

## Verification scope
- Added targeted regression tests for horizontal tool labels, all 16 tool cards, scientific grid dimensions, touch target sizing, and unique control IDs.
- JavaScript syntax, YAML parsing, ZIP integrity, and automated regression suite are release gates.
- Physical-device APK installation, touch-latency measurement, and frame-rate certification require an Android device and are not claimed here.
