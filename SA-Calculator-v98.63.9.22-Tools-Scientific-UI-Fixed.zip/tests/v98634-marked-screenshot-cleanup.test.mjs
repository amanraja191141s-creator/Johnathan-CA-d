import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const css=fs.readFileSync(path.join(root,'assets/css/app.css'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
test('bottom dock no longer adds a second safe-area height or padding band',()=>{
  assert.match(css,/flex:0 0 var\(--sa-dock-height,68px\)!important/);
  assert.match(css,/height:var\(--sa-dock-height,68px\)!important/);
  assert.match(css,/padding:3px 5px!important/);
});
test('currency picker keeps a bounded header and vertically scrolling structured options',()=>{
  assert.match(css,/\.sumaire-picker-heading\s*\{[^}]*text-overflow:\s*ellipsis\s*!important/);
  assert.match(css,/\.sumaire-picker-options\s*\{[^}]*overflow-y:\s*auto\s*!important/);
  assert.match(css,/\.sumaire-picker-option\s*\{[^}]*grid-template-columns:\s*38px minmax\(0,1fr\) 22px\s*!important/);
  assert.match(js,/option\.textContent = `\$\{code\} — \$\{localizedCurrencyName\(code\)/);
});
test('currency rate card removes duplicate visible status and timestamps but retains live status nodes',()=>{
  assert.match(html,/id="cur-rate-status"/);
  assert.match(html,/id="cur-refresh-time"/);
  assert.match(css,/#screen-currencies \.currency-rate-status,[\s\S]*?#screen-currencies \.currency-refresh-time\{/);
  assert.match(css,/#screen-currencies #cur-rate-note\{/);
});
test('currency converter has no redundant manual Convert action and picker does not auto-open the keyboard',()=>{
  const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
  assert.doesNotMatch(html,/id="currency-convert-action"/);
  assert.doesNotMatch(js,/searchInput\.focus\(\{ preventScroll: true \}\)/);
  assert.match(css,/#screen-currencies #currency-convert-action/);
  assert.match(css,/display:none!important/);
});
