import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');

test('Tools catalogue has grouped 3-column cards with horizontal, non-destructive labels', () => {
  assert.match(html, /class="premium-tools-grid tools-reference-groups"/);
  assert.equal((html.match(/class="premium-tool-card"/g) || []).length, 16);
  assert.match(css, /#screen-tools \.tools-reference-grid\s*\{[^}]*grid-template-columns:repeat\(3,minmax\(0,1fr\)\)!important/s);
  assert.match(css, /#screen-tools \.premium-tool-card \.premium-tool-name\s*\{[^}]*writing-mode:horizontal-tb!important/s);
  assert.match(css, /overflow-wrap:normal!important/);
  assert.match(css, /word-break:normal!important/);
  assert.match(css, /-webkit-line-clamp:2!important/);
});

test('Scientific keypad exposes a stable 4x4 function grid and readable touch targets', () => {
  const start = html.indexOf('id="screen-scientific"');
  const end = html.indexOf('</section>', start);
  const sci = html.slice(start, end);
  assert.ok(start >= 0 && end > start);
  assert.equal((sci.match(/class="scientific-function-grid"/g) || []).length, 1);
  assert.equal((sci.match(/data-sci-insert=/g) || []).length >= 15, true);
  assert.match(css, /#screen-calc #screen-scientific \.scientific-function-grid\s*\{[^}]*grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/s);
  assert.match(css, /#screen-calc #screen-scientific \.scientific-function-grid > button\s*\{[^}]*min-height:42px!important/s);
  assert.match(js, /data-sci-alt-insert/);
  assert.match(js, /toggle-angle/);
});

test('Scientific modifier and angle controls remain uniquely identified and accessible', () => {
  for (const id of ['sci-shift-toggle', 'sci-angle-toggle', 'sci-drawer-close', 'sci-more-toggle']) {
    assert.equal((html.match(new RegExp(`id="${id}"`, 'g')) || []).length, 1, `${id} must be unique`);
  }
  assert.match(html, /aria-pressed="false"/);
  assert.match(html, /aria-expanded="false" aria-controls="sci-more-functions"/);
});
