# v98.63.9.13 — Converter keypad and calculator-first cleanup

- Fixed popup keypad field-label resolution: unit/currency select option inventories can no longer leak into keypad headings or preview labels.
- Converter keypad labels are now concise and explicit: Value, Amount, Converted amount.
- Select-wrapper text is excluded from generic label discovery across all tools.
- Removed the legacy app header from the calculator active surface so calculator display and keypad use the full available vertical workspace; tool screens retain the header.
- Preserved selected currency/unit controls, conversion logic, docked numeric keypads, navigation and calculator functionality.
